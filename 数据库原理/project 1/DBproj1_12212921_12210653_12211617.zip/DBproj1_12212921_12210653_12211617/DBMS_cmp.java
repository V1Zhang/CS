import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

import java.io.*;
import java.util.*;

public class DBMS_cmp {
    static CsvReader csvReader;
    static CsvWriter csvWriter;
    static String[] bv = new String[12478997];
    static long[] mid = new long[12478997];
    static float[] time = new float[12478997];
    static int[] aid = new int[1000000];
    static int[] bid = new int[1000000];
    static int[] ambalance = new int[1000000];

    static String[] content = new String[12478997];

    public static void main(String[] args) {
        String filename = "E:\\Database_proj_1\\data\\pgbench_accounts.csv";

        int cnt = 0;
        long start = System.currentTimeMillis();
        try {
            csvReader = new CsvReader(new FileReader(filename));
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filename, true));
            csvWriter = new CsvWriter(bufferedWriter, ',');
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                //danmu
//                bv[cnt] = csvReader.get(0);
//                mid[cnt] = Long.parseLong(csvReader.get(1));
//                time[cnt] = Float.parseFloat(csvReader.get(2));
//                content[cnt] = csvReader.get(3);
                //pgbench
                aid[cnt] = Integer.parseInt(csvReader.get(0));
                bid[cnt] = Integer.parseInt(csvReader.get(1));
                ambalance[cnt] = Integer.parseInt(csvReader.get(2));


                cnt++;
            }
            csvReader.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        long end = System.currentTimeMillis();
        System.out.printf("Runtime of import data is: %dms and has %d rows\n", (end - start), cnt);

        select();
      insert();
        max();
        count();

          group_by(bv);


    }

    private static List<String> select() {
        Random random = new Random();
        int _aid = random.nextInt(1000000);
        long start = System.nanoTime();
        int cnt = 0;
        List<String> ans = new ArrayList<String>();
        for (int i = 0; i < 1000000; i++) {
            //conditional select
//            if (content[i] != null && content[i].contains("原神")) {
//                ans.add(content[i]);
//                cnt++;
//            }
            if (aid[i] == _aid)
                ans.add(String.valueOf(ambalance[i]));
            cnt++;
        }
        long end = System.nanoTime();
        System.out.printf("Runtime of select is %d ns and %d rows\n", (end - start), cnt);
        return ans;
    }

    private static void insert() {
        long start = System.nanoTime();
        String[] comment = {"BVhfkhaj", "123456", "0.1", "nothing"};
        try {
            for (int i = 0; i < 1000; i++) {
                csvWriter.writeRecord(comment);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        long end = System.nanoTime();
        csvWriter.close();
        System.out.printf("Runtime of insert is %d microsecond\n", (end - start) / 1000);
    }

    private static long max() {
        long start = System.nanoTime();
        long max_mid = 0;
        for (int i = 0; i < 1000000; i++) {
            if (mid[i] > max_mid) {
                max_mid = mid[i];
            }
        }
        long end = System.nanoTime();
        System.out.printf("Runtime of max is %d microsecond\n", (end - start) / 1000);
        return max_mid;
    }

    private static long count() {
        long start = System.nanoTime();
        int cnt = 0;
        for (int i = 0; i < 1000000; i++) {
            if (time[i] > 10) {
                cnt++;
            }
        }
        long end = System.nanoTime();
        System.out.printf("Runtime of count is %d microsecond\n", (end - start) / 1000);
        return cnt;
    }

    public static String[] group_by(String[] array) {
        long start = System.currentTimeMillis();

        HashMap<String, Integer> hashMap = new HashMap<>();

        // 遍历数组并将元素插入HashMap
        for (String element : array) {
            hashMap.put(element, 0);
        }

        // 获取去重后的元素
        HashSet<String> uniqueElements = new HashSet<>(hashMap.keySet());
        long end = System.currentTimeMillis();
        System.out.printf("Runtime of group by is %dms and %d rows", end - start, uniqueElements.size());
        // 将去重后的元素转换为数组并返回
        return uniqueElements.toArray(new String[0]);
    }
}
