CREATE TYPE sex AS ENUM ('保密', '男', '女');
CREATE TYPE level AS ENUM ('0','1','2','3','4','5','6');
CREATE TYPE identity AS ENUM ('user', 'superuser');

create table users
(
    Mid       bigint   primary key,
    Name      text     not null,
    Sex       sex      not null,
    Birthday  date     NULL,
    Level     level    not null,
    Sign      text     NULL,
    Following bigint[],
    Identity  identity not null
);

DROP TABLE users;



create table videos
(
    BV             char(12)        primary key,
    Title          text            not null,
    Owner_Mid      bigint          REFERENCES users(Mid),
    Owner_Name     text            not null,
    Commit_Time    timestamp       not null,
    Review_Time    timestamp       not null,
    Public_Time    timestamp       not null,
    Duration       bigint          not null,
    Description    text            null,
    Reviewer       text,
    likes          bigint[]        null,
    coin           bigint[]         null,
    favorite       bigint[]        null
);

DROP TABLE videos;


create table danmu
(
    id       bigint        primary key ,
    BV       char(12)      REFERENCES videos (BV),
    Mid      bigint        not null REFERENCES users (mid),
    Time     float         not null,
    Content  text,
    CONSTRAINT fk_danmu_videos FOREIGN KEY (BV) REFERENCES videos (BV),
    CONSTRAINT fk_danmu_users FOREIGN KEY (Mid) REFERENCES users (mid)
);

DROP TABLE danmu;




create table likes
(
    BV            char(12)         primary key REFERENCES videos (BV),
    likeValue     bigint           not null,
    CONSTRAINT fk_likes_videos FOREIGN KEY (BV) REFERENCES videos (BV)
);

DROP TABLE likes;


create table coins
(
    BV            char(12)         primary key REFERENCES videos (BV),
    coin          bigint           not null,
    CONSTRAINT fk_coins_videos FOREIGN KEY (BV) REFERENCES videos (BV)

);

DROP TABLE coins;


create table favorites
(
    BV            char(12)        primary key REFERENCES videos (BV),
    favorite     bigint          not null,
    CONSTRAINT fk_favourites_videos FOREIGN KEY (BV) REFERENCES videos (BV)

);

DROP TABLE favorites;



CREATE TABLE views
(
    video_BV  char(12) REFERENCES videos (BV),
    user_id   bigint,
    stop_time bigint,
    PRIMARY KEY (video_BV, user_id),
    CONSTRAINT fk_views_videos FOREIGN KEY (video_BV) REFERENCES videos (BV)
);

DROP TABLE views;








ALTER TABLE danmu
DROP CONSTRAINT fk_danmu_users;

ALTER TABLE danmu SET UNLOGGED;
ALTER TABLE users SET UNLOGGED;

CREATE TABLE logged_users AS SELECT * FROM users;
DROP TABLE users;
ALTER TABLE logged_users RENAME TO users;

drop table logged_users;



COPY users( Mid, Name, Sex, Birthday, Level, Sign, Following, Identity) FROM 'C:\Users\lenovo\DataGripProjects\DBproj1\data\danmu.csv' with CSV HEADER;
