import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Properties;
import java.sql.*;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.csvreader.*;

public class DataLoader {
    private static final int BATCH_SIZE = 100;
    //增大批处理大小通常会提高数据加载的性能，因为每次插入的数据行数更多，减少了与数据库的通信开销。这可以加快数据加载速度。
    //增大批处理大小同时可能会导致内存消耗增加，因为需要在内存中维护较大的数据批次。如果批处理过大，可能会导致内存不足错误或性能下降。
    private static URL propertyURL = DataLoader.class
            .getResource("/loader.cnf");
    private static Connection con = null;
    //声明了一个静态数据库连接对象con，用于与数据库建立连接
    private static PreparedStatement stmt = null;
    //声明了一个静态预处理语句对象stmt，用于执行数据库插入操作。
    private static boolean verbose = false;
    private static void openDB(String host, String dbname,
                               String user, String pwd) {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (Exception e) {
            System.err.println("Cannot find the Postgres driver. Check CLASSPATH.");
            System.exit(1);
        }
        String url = "jdbc:postgresql://" + host + "/" + dbname;
        Properties props = new Properties();
        props.setProperty("user", user);
        props.setProperty("password", pwd);
        try {
            con = DriverManager.getConnection(url, props);
            if (verbose) {
                System.out.println("Successfully connected to the database "
                        + dbname + " as " + user);
            }
            con.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Database connection failed");
            System.err.println(e.getMessage());
            System.exit(1);
        }
        try {
            // choose the sql for the target table
            stmt = con.prepareStatement("insert into users(Mid,Name,Sex,Birthday,Level,Sign,following,identity)" + " values(?,?,?,?,?,?,?,?)");
            // stmt = con.prepareStatement("insert into videos(BV,Title,Owner_Mid,Owner_Name,Commit_Time,Review_Time,Public_Time,Duration,Description,Reviewer)" + " values(?,?,?,?,?,?,?,?,?,?)");
            // stmt = con.prepareStatement("insert into danmu(id, BV,Mid,Time,Content)" + " values(?,?,?,?,?)");
            // stmt = con.prepareStatement("insert into coins(BV,coin)" + " values(?,?)");
            // stmt = con.prepareStatement("insert into favorites(BV,favorite)" + " values(?,?)");
            //stmt = con.prepareStatement("insert into likes(BV,likeValue)" + " values(?,?)");
            //stmt = con.prepareStatement("insert into views(video_BV,user_id,stop_time)" + " values(?,?,?)");
        } catch (SQLException e) {
            System.err.println("Insert statement failed");
            System.err.println(e.getMessage());
            closeDB();
            System.exit(1);
        }
    }

    private static void closeDB() {
        if (con != null) {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                con.close();
                con = null;
            } catch (Exception e) {
                // Forget about it
            }
        }
    }

    // choose the correct
    private static void loadData_users(Long Mid, String Name, String Sex, String Birthday, Integer Level, String Sign, Long[] following, String identity)
            throws SQLException {
        if (con != null) {
            stmt.setLong(1, Mid);
            stmt.setString(2, Name);
            stmt.setObject(3, Sex, Types.OTHER);

            if (Birthday != "") {
                Pattern pattern = Pattern.compile("(\\d+)月(\\d+)日");
                Matcher matcher = pattern.matcher(Birthday);
                int month = -1;
                int day = -1;

                if (matcher.find()) {
                    month = Integer.parseInt(matcher.group(1));
                    day = Integer.parseInt(matcher.group(2));
                }
                if (month != -1 && day != -1) {
                    LocalDate date = LocalDate.of(2000, month, day);
                    stmt.setDate(4, Date.valueOf(date));
                }
            }
            stmt.setObject(5, Level, Types.OTHER);
            stmt.setString(6, Sign);
            Array following_array = con.createArrayOf("bigint", following);
            stmt.setArray(7, following_array);
            stmt.setObject(8, identity, Types.OTHER);
            stmt.addBatch();
        }
    }

    private static void loadData_videos(String BV,String Title,Long Owner_Mid,String Owner_Name,Timestamp Commit_Time,Timestamp Review_Time,Timestamp Public_Time,Integer Duration,String Description,String Reviewer)
            throws SQLException {
        if (con != null) {
            stmt.setString(1, BV);
            stmt.setString(2, Title);
            stmt.setLong(3, Owner_Mid);
            stmt.setString(4, Owner_Name);
            stmt.setTimestamp(5, Commit_Time);
            stmt.setTimestamp(6, Review_Time);
            stmt.setTimestamp(7, Public_Time);
            stmt.setInt(8, Duration);
            stmt.setString(9, Description);
            stmt.setString(10, Reviewer);
            stmt.addBatch();
        }
    }

    private static void loadData_danmu(Long id, String BV, Long Mid, Double Time, String Content)
            throws SQLException {
        if (con != null) {
            stmt.setLong(1,id);
            stmt.setString(2, BV);
            stmt.setLong(3, Mid);
            stmt.setDouble(4, Time);
            stmt.setObject(5, Content);
            stmt.addBatch();
        }
    }

    private static void loadData_coin(String BV,Long coin)
            throws SQLException {
        if (con != null) {
            stmt.setString(1, BV);
            stmt.setLong(2, coin);
            stmt.addBatch();
        }
    }

    private static void loadData_favourite(String BV,Long favorite)
            throws SQLException {
        if (con != null) {
            stmt.setString(1, BV);
            stmt.setLong(2, favorite);
            stmt.addBatch();
        }
    }

    private static void loadData_like(String BV,Long likeValue)
            throws SQLException {
        if (con != null) {
            stmt.setString(1, BV);
            stmt.setLong(2, likeValue);
            stmt.addBatch();
        }
    }

    private static void loadData_view(String video_BV,Long user_id,Long stop_time)
            throws SQLException {
        if (con != null) {
            stmt.setString(1, video_BV);
            stmt.setLong(2, user_id);
            stmt.setLong(3, stop_time);
            stmt.addBatch();
        }
    }
    public static void main_users(String[] args) {
        String fileName = null;
        args = new String[]{"-v", "users.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            int cnt = 0;
            long start;
            long end;
            csvReader.readHeaders();
            String[] parts = new String[100];
            long Mid;
            String Name;
            String Sex;
            String Birthday;
            int Level;
            String Sign;
            Long[] following;
            String identity;


            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            while (csvReader.readRecord()) {
                for (int i = 0; i < csvReader.getColumnCount(); i++) {
                    parts[i] = csvReader.get(csvReader.getHeader(i));
                }
                //对于每一列 用列名读取内容
                Mid = Long.parseLong(parts[0]);
                Name = parts[1];
                Sex = parts[2];
                Birthday = parts[3];
                Level = Integer.parseInt(parts[4]);
                Sign = parts[5];
                long len = parts[6].length();
                if (len > 2) {
                    String[] array = parts[6].substring(2, parts[6].length() - 2).split(", ");
                    Long[] following_array = new Long[array.length];
                    for (int i = 0; i < array.length; i++) {
                        following_array[i] = Long.valueOf(array[i].substring(1, array[i].length() - 1));
                    }
                    following = following_array;
                } else {
                    following = new Long[0];
                }
                identity = parts[7];
                loadData_users(Mid, Name, Sex, Birthday, Level, Sign, following, identity);
                cnt++;
                if (cnt % BATCH_SIZE == 0) {
                    stmt.executeBatch();
                    stmt.clearBatch();
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();




            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }
    public static void main_videos(String[] args) {
        String fileName = null;

        args = new String[]{"-v", "videos.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.setSafetySwitch(false);
            csvReader.readHeaders();
            long start;
            long end;
            String[] parts = new String[100];

            String BV;
            String Title;
            long Owner_Mid;
            String Owner_Name;
            Timestamp Commit_Time;
            Timestamp Review_Time;
            Timestamp Public_Time;
            int Duration;
            String Description;
            String Reviewer;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            while (csvReader.readRecord()) {
                // 仅读取前九列的内容
                for (int i = 0; i < 9; i++) {
                    parts[i] = csvReader.get(csvReader.getHeader(i));
                }
                //对于每一列 用列名读取内容
                BV = parts[0];
                Title = parts[1];
                Owner_Mid = Long.parseLong(parts[2]);
                Owner_Name = parts[3];
                Commit_Time = Timestamp.valueOf(parts[4]); // 从 CSV 文件中读取日期时间字符串
                Review_Time = Timestamp.valueOf(parts[5]);
                Public_Time = Timestamp.valueOf(parts[6]);
                Duration = Integer.parseInt(parts[7]);
                Description = parts[8];
                Reviewer = parts[9];

                loadData_videos(BV, Title, Owner_Mid, Owner_Name, Commit_Time, Review_Time, Public_Time, Duration, Description, Reviewer);
                cnt++;
                if (cnt % BATCH_SIZE == 0) {
                    stmt.executeBatch();
                    stmt.clearBatch();
                }
            }

            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }

    public static void main_danmu(String[] args) {
        String fileName = null;
        args = new String[]{"-v", "danmu.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }
        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.readHeaders();
            long start;
            long end;
            String[] parts = new String[100];
            long id = 0;
            String BV;
            long Mid;
            double Time;
            String Content;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));
            Statement stmt0;
            if (con != null) {
                stmt0 = con.createStatement();
                stmt0.execute("truncate table danmu");
                stmt0.close();
            }

            while (csvReader.readRecord()) {
                for (int i = 0; i < csvReader.getColumnCount(); i++) {
                    parts[i] = csvReader.get(csvReader.getHeader(i));
                }
                //对于每一列 用列名读取内容
                id+=1;
                BV = parts[0];
                Mid = Long.parseLong(parts[1]);
                Time = Double.parseDouble(parts[2]);
                Content = parts[3];

                loadData_danmu(id,BV, Mid, Time, Content);
                cnt++;
                if (cnt % BATCH_SIZE == 0) {
                    stmt.executeBatch();
                    stmt.clearBatch();
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }
    public static void main_coin(String[] args) {
        String fileName = null;

        args = new String[]{"-v", "videos.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.setSafetySwitch(false);

            csvReader.readHeaders();
            long start;
            long end;
            String BV;
            long coin;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            Statement stmt0;
            if (con != null) {
                stmt0 = con.createStatement();
                stmt0.execute("truncate table coins");
                stmt0.close();
            }

            while (csvReader.readRecord()) {
                long len = csvReader.get("Coin").length();
                if (len > 2) {
                    String[] coins = csvReader.get("Coin").substring(1, csvReader.get("Coin").length() - 1).split(", ");
                    for (String co : coins) {
                        BV = csvReader.get(csvReader.getHeader(0));
                        coin = Long.parseLong(co.substring(1, co.length()-1));
                        //insert in the circle!
                        loadData_coin(BV,coin);
                        cnt++;

                        if (cnt % BATCH_SIZE == 0) {
                            stmt.executeBatch();
                            stmt.clearBatch();
                        }
                    }
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }
    public static void main_favourite(String[] args) {
        String fileName = null;

        args = new String[]{"-v", "videos.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.setSafetySwitch(false);

            csvReader.readHeaders();
            long start;
            long end;
            String BV;
            long favorite;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            Statement stmt0;
            if (con != null) {
                stmt0 = con.createStatement();
                stmt0.execute("truncate table favorites");
                stmt0.close();
            }

            while (csvReader.readRecord()) {
                long len = csvReader.get("Favorite").length();
                if (len > 2) {
                    String[] favorites = csvReader.get("Favorite").substring(1, csvReader.get("Favorite").length() - 1).split(", ");
                    for (String fav : favorites) {
                        BV = csvReader.get(csvReader.getHeader(0));
                        favorite = Long.parseLong(fav.substring(1, fav.length()-1));
                        //insert in the circle!
                        loadData_favourite(BV,favorite);
                        cnt++;

                        if (cnt % BATCH_SIZE == 0) {
                            stmt.executeBatch();
                            stmt.clearBatch();
                        }

                    }
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }
    public static void main_like(String[] args) {
        String fileName = null;

        args = new String[]{"-v", "videos.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.setSafetySwitch(false);

            csvReader.readHeaders();
            long start;
            long end;
            String BV;
            long likeValue;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            Statement stmt0;
            if (con != null) {
                stmt0 = con.createStatement();
                stmt0.execute("truncate table likes");
                stmt0.close();
            }

            while (csvReader.readRecord()) {
                long len = csvReader.get("Like").length();
                if (len > 2) {
                    String[] likeValues = csvReader.get("Like").substring(1, csvReader.get("Like").length() - 1).split(", ");
                    for (String like : likeValues) {
                        BV = csvReader.get(csvReader.getHeader(0));
                        likeValue = Long.parseLong(like.substring(1, like.length()-1));
                        //insert in the circle!
                        loadData_like(BV,likeValue);
                        cnt++;

                        if (cnt % BATCH_SIZE == 0) {
                            stmt.executeBatch();
                            stmt.clearBatch();
                        }

                    }
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }

    public static void main_view(String[] args) {
        String fileName = null;
        args = new String[]{"-v", "videos.csv"};

        switch (args.length) {
            case 1:
                fileName = args[0];
                break;
            case 2:
                switch (args[0]) {
                    case "-v":
                        verbose = true;
                        break;
                    default:
                        System.err.println("Usage: java [-v] DataLoader filename");
                        System.exit(1);
                }
                fileName = args[1];
                break;
            default:
                System.err.println("Usage: java [-v] DataLoader filename");
                System.exit(1);
        }

        if (propertyURL == null) {
            System.err.println("No configuration file (loader.cnf) found");
            System.exit(1);
        }
        Properties defprop = new Properties();
        defprop.put("host", "127.0.0.1");
        defprop.put("user", "postgres");
        defprop.put("password", "Zwy20040430");
        defprop.put("database", "postgres");
        Properties prop = new Properties(defprop);
        try (BufferedReader conf
                     = new BufferedReader(new FileReader(propertyURL.getPath()))) {
            prop.load(conf);
        } catch (IOException e) {
            // Ignore
            System.err.println("No configuration file (loader.cnf) found");
        }
        try {
            // 创建CSV读对象
            CsvReader csvReader = new CsvReader(new FileReader(fileName));
            csvReader.setSafetySwitch(false);

            csvReader.readHeaders();
            long start;
            long end;
            String video_BV = null;
            Long user_id = null;
            Long stop_time = null;
            int cnt = 0;

            start = System.currentTimeMillis();
            openDB(prop.getProperty("host"), prop.getProperty("database"),
                    prop.getProperty("user"), prop.getProperty("password"));

            Statement stmt0;
            if (con != null) {
                stmt0 = con.createStatement();
                stmt0.execute("truncate table views");
                stmt0.close();
            }

            while (csvReader.readRecord()) {
                long len = csvReader.get("View").length();
                if (len > 2) {
                    String[] array = csvReader.get("View").substring(1, csvReader.get("View").length() - 1).split(", (?![^()]*\\))");
                    for (int i = 0; i < array.length; i++) {
                        video_BV = csvReader.get(csvReader.getHeader(0));
                        String[] temp = array[i].substring(1, array[i].length() - 1).split(", ");
                        user_id = Long.valueOf(temp[0].substring(1,temp[0].length()-1));
                        stop_time = Long.valueOf(temp[1]);
                        //insert in the circle!
                        loadData_view(video_BV,user_id,stop_time);
                        cnt++;
                        if (cnt % BATCH_SIZE == 0) {
                            stmt.executeBatch();
                            stmt.clearBatch();
                        }
                    }
                }
            }
            csvReader.close();
            if (cnt % BATCH_SIZE != 0) {
                stmt.executeBatch();
            }
            con.commit();
            stmt.close();

            closeDB();
            end = System.currentTimeMillis();
            System.out.println(cnt + " records successfully loaded");
            System.out.println("Loading speed : "
                    + (cnt * 1000L) / (end - start)
                    + " records/s");
        } catch (IOException e) {
            System.err.println("Fatal error: " + e.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        } catch (SQLException se) {
            System.err.println("SQL error: " + se.getMessage());
            try {
                con.rollback();
                stmt.close();
            } catch (Exception e2) {
            }
            closeDB();
            System.exit(1);
        }
        closeDB();
    }
    public static void main(String[] args) {
        main_users(args);
        // main_videos(args);
        // main_danmu(args);
        // main_coin(args);
        // main_favourite(args);
        // main_like(args);
        // main_view(args);
    }





}

