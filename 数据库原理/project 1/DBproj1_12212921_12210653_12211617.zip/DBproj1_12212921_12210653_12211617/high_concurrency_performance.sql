select  * from pg_settings;

--show state
show wal_buffers;
show work_mem;
show shared_buffers;
show synchronous_commit;
show full_page_writes;
show  maintenance_work_mem ;

--default state
alter system set full_page_writes = on;
alter system set wal_buffers = 512;
alter system set synchronous_commit = on;
alter system set shared_buffers = 16384;
alter system set work_mem = 4096;
alter system set maintenance_work_mem = 8192;


--optimized state
alter system set full_page_writes = off;
alter system set wal_buffers = 4096;
alter system set synchronous_commit = off;
alter system set shared_buffers = 524288;
alter system set work_mem = 8192;
alter system set maintenance_work_mem = 131072;
