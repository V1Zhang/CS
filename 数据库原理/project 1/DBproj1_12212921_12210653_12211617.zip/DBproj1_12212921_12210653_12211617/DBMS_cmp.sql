create table danmu
(
    BV      char(12),
    Mid     bigint not null,
    Time    float  not null,
    Content text,
    id      serial

);
--disk performance compare
COPY danmu (BV, Mid, Time, Content)
    FROM 'E:\Database_proj_1\data\danmu.csv' DELIMITER ',' CSV header;

COPY danmu (BV, Mid, Time, Content)
    FROM 'F:\danmu.csv' DELIMITER ',' CSV header;

truncate table danmu;


--select experiment 1
explain analyse
select bv
from danmu
limit 100000;


--select experiment 2
explain analyse
select count(Content)
from danmu
where Content like '%原神%'
  and time < 10
;


-- explain analyse;
explain analyse
insert into danmu (bv, mid, time, content)
values ('BVhfkhaj', 123456, 0.1, 'nothing');


--aggregate function
explain analyse
select count(*)
from (select BV
      from danmu
      group by BV) sub;