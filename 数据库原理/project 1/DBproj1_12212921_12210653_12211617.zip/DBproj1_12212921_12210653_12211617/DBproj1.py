import csv
import psycopg2
import time


def load_data(filename):
    # 设置数据库连接参数
    db_params = {
        'host': '127.0.0.1',
        'database': 'postgres',
        'user': 'postgres',
        'password': 'Zwy20040430'
    }

    start_time = time.time()
    # 打开 CSV 文件
    with open(filename, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)

        # 连接到 PostgreSQL 数据库
        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()

        # 清空目标表
        cursor.execute("TRUNCATE TABLE danmu;")

        # 准备插入数据的 SQL 语句
        insert_query = "INSERT INTO danmu(id, BV, Mid, Time, Content) VALUES (%s, %s, %s, %s, %s);"

        id = 0
        batch_size = 500
        data_batch = []

        next(reader)
        for row in reader:
            BV, Mid, Time, Content = row
            id = id+1  # 自动生成 id

            # 将数据添加到批处理中
            data_batch.append((id, BV, Mid, Time, Content))

            if len(data_batch) >= batch_size:
                cursor.executemany(insert_query, data_batch)
                data_batch = []

        if data_batch:
            cursor.executemany(insert_query, data_batch)

        conn.commit()
        cursor.close()
        conn.close()
        end_time = time.time()
        time_taken = end_time - start_time

        print("The time cost is：", time_taken, "s")

if __name__ == '__main__':
    filename = 'danmu.csv'  # 你的CSV文件路径
    load_data(filename)
