CREATE TABLE test_data
(
    id    SERIAL PRIMARY KEY,
    value INTEGER
);

INSERT INTO test_data (value)
SELECT generate_series(1, 10000000);
drop table  test_data;

select count(*)
from test_data;

